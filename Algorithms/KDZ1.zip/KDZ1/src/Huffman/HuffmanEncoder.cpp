//
// Created by Ivan on 3/15/2018.
//

#include <queue>
#include <iostream>
#include "HuffmanEncoder.h"

std::map<unsigned char, int> countLetters(const unsigned char* text, const std::size_t& n)
{
    std::map<unsigned char, int> count;
    for(int i = 0; i < n; ++i)
    {
        if(count.count(text[i]) > 0)
            count[text[i]] += 1;
        else
            count[text[i]] = 1;
    }
    return count;
}

struct HuffmanNode
{
    HuffmanNode(unsigned char latter, int value)
    {
        this->value = value;
        this->lattersToCodes[latter] = Code();
    }

    HuffmanNode& concatenate(HuffmanNode& hNode)
    {
        for(auto& code : lattersToCodes)
            code.second.eraseByOne();

        for(auto& code : hNode.lattersToCodes)
            code.second.eraseByZero();

        this->value += hNode.value;
        this->lattersToCodes.insert(hNode.lattersToCodes.begin(), hNode.lattersToCodes.end());
        return *this;
    }

    struct less
    {
        bool operator()(const HuffmanNode& first, const HuffmanNode& second)
        {
            return first.value > second.value;
        }
    };

    int value;
    std::map<unsigned char, Code> lattersToCodes;
};

void HuffmanEncoder::createEncodeTable(const unsigned char* text, std::size_t n)
{
    std::priority_queue<HuffmanNode, std::vector<HuffmanNode>, HuffmanNode::less> pq;

    auto count = countLetters(text, n);
    for(auto it = count.begin(); it != count.end(); ++it)
        pq.push(HuffmanNode(it->first, it->second));

    while(pq.size() > 1)
    {
        HuffmanNode a = pq.top();
        pq.pop();
        HuffmanNode b = pq.top();
        pq.pop();
        pq.push(a.concatenate(b));
    }

    encodeTable = pq.top().lattersToCodes;
}

void HuffmanEncoder::createDecodeTable(const unsigned char* text, std::size_t n)
{

}

//unsigned char* HuffmanEncoder::concatenateCodes(const unsigned char* code1, std::size_t len1, const unsigned char* code2, std::size_t len2, std::size_t& len)
//{
//    if(len1 == 0 || len2 == 0)
//        throw std::invalid_argument("len1 == 0 || len2 == 0");
//
//    len = len1 + len2;
//    int n = len % 8 == 0 ? len / 8 : len / 8 + 1;
//    unsigned char* code = new unsigned char[n];
//
//    int i = 0;
//    for(int p = len1 / 8; i < p; ++i)
//        code[i] = code1[i];
//
//    unsigned char k1 = (unsigned char)(len1 % 8);
//    if(len2 + k1 <= 8)
//    {
//        code[i] = (code1[i] << len2) | code2[0];
//        return code;
//    }
//
//    code[i] = (code1[i] << (8 - k1)) | (code2[0] >> k1);
//    int j = 1, p = len2 - 8 + k1;
//    for(; p >= 8; ++j, p -= 8)
//        code[i + j] = (code2[j - 1] << (8 - k1)) | (code2[j] >> k1);
//
//    unsigned char k2 = (unsigned char)(len2 % 8);
//    if(p > k1)
//        code[i + j] = ((code2[j - 1] & (unsigned char)((1 << k1) - 1)) << k2) | code2[j];
//    else
//        code[i + j] = code2[j - 1];
//
//    return code;
//}

void appendCode(std::vector<unsigned char>& code, std::size_t& codeLen, Code c)
{
    std::vector<unsigned char> valueCode;
    int value;
    if(code.empty() || codeLen % 8 == 0) {
        value = c.getValue();
    } else {
        value = (code.back() << c.getLen()) | c.getValue();
        code.pop_back();
    }

    int len = codeLen % 8 + c.getLen(), chunk = len % 8;
    if(chunk != 0) {
        valueCode.push_back((unsigned char) (value % (1 << chunk)));
        value >>= chunk;
        len -= chunk;
    }

    for(; len > 0; value >>= 8, len -= 8)
        valueCode.push_back((unsigned char)(value % 0x100));

    for(auto vc = valueCode.rbegin(); vc != valueCode.rend() ; ++vc)
        code.push_back(*vc);
    codeLen += c.getLen();
}

unsigned char* HuffmanEncoder::encode(const unsigned char* text, std::size_t textLen, std::size_t& codeLen)
{
    if(textLen == 0)
        throw std::invalid_argument("n == 0");

    if(encodeTable.empty())
        createEncodeTable(text, textLen);

    std::vector<unsigned char> code;
    code.reserve(textLen / 3);
    for(int i = 0; i < textLen; ++i)
        appendCode(code, codeLen, encodeTable[text[i]]);
//    std::cout << (int)code[0];
    return code.data();
}

unsigned char* HuffmanEncoder::decode(const unsigned char* text, std::size_t codeLen, std::size_t& textLen)
{
    return nullptr;
}


