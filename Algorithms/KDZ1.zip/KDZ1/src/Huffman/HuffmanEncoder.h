//
// Created by Ivan on 3/15/2018.
//

#ifndef KDZ1_HUFFMANENCODER_H
#define KDZ1_HUFFMANENCODER_H


#include <map>
#include "../Encoder.h"
#include "Code.h"

class HuffmanEncoder : public Encoder
{
public:
    HuffmanEncoder() = default;

    explicit HuffmanEncoder(std::map<unsigned char, Code>& table)
    {
        this->encodeTable = table;
    }

    unsigned char* encode(const unsigned char* text, std::size_t textLen, std::size_t& codeLen) override;

    unsigned char* decode(const unsigned char* text, std::size_t codeLen, std::size_t& textLen) override;

    void createEncodeTable(const unsigned char* text, std::size_t n);

    void createDecodeTable(const unsigned char* text, std::size_t n);

//    unsigned char* concatenateCodes(const unsigned char* code1, std::size_t len1, const unsigned char* code2, std::size_t len2, std::size_t& len);

private:
    std::map<unsigned char, Code> encodeTable;

    std::map<unsigned char, Code> decodeTable;

#ifdef DEBUG
public:
    unsigned char* concatenateCodes_forTest(const unsigned char* code1, int len1, const unsigned char* code2, int len2, int& len)
    {
        return concatenateCodes(code1, len1, code2, len2, len);
    };
#endif //DEBUG
};


#endif //KDZ1_HUFFMANENCODER_H
