//
// Created by Ivan on 3/15/2018.
//

#include "Code.h"

void Code::eraseByZero()
{
    ++len;
}

void Code::eraseByOne()
{
    value = 1 << len | value;
    ++len;
}

void Code::insertBegin(unsigned char v, unsigned char l)
{
    this->value = v << this->len + value;
    this->len += l;
}
