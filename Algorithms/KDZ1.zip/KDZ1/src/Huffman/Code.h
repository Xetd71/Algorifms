//
// Created by Ivan on 3/15/2018.
//

#ifndef KDZ1_CODE_H
#define KDZ1_CODE_H

#include <vector>

class Code
{
public:
    Code() : value(0), len(0) { }

    Code(unsigned int value, unsigned int len) : value(value), len(len) { }

    void eraseByZero();

    void eraseByOne();

    void insertBegin(unsigned char v, unsigned char l);

    const unsigned int& getValue() { return value; }

    const unsigned int& getLen() { return len; }

private:
    unsigned int value;

    unsigned int len;
};

#endif //KDZ1_CODE_H
