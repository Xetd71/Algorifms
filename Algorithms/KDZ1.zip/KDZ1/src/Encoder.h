//
// Created by Ivan on 3/15/2018.
//

#ifndef KDZ1_ENCODER_H
#define KDZ1_ENCODER_H


class Encoder
{
public:
    virtual unsigned char* encode(const unsigned char* text, std::size_t textLen, std::size_t& codeLen) = 0;

    virtual unsigned char* decode(const unsigned char* code, std::size_t codeLen, std::size_t& textLen) = 0;
};


#endif //KDZ1_ENCODER_H
