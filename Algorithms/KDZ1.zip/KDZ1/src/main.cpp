#include <iostream>
#include <vector>

int main()
{
    std::vector<unsigned char> v;
    v.push_back(1);
    v.push_back(2);
    v.push_back(3);
    unsigned char* data = v.data();
    for(int i = 0; i < 3; ++i) {
        std::cout << (int)data[i];
    }
    return 0;
}