//
// Created by Ivan on 3/15/2018.
//

#include <gtest/gtest.h>

#include "../src/Huffman/HuffmanEncoder.h"

TEST(HuffmanEncoder, simple)
{
    HuffmanEncoder he;
    unsigned char* c;
    std::size_t codeLen;
    he.encode(c, 0, codeLen);
}

//TEST(HuffmanEncoder, concatenateCodes)
//{
//    HuffmanEncoder he;
//
//    unsigned char code1[] = {0b10101100, 0b00000101};
//    int len1 = 11;
//    unsigned char code2[] = {0b00110100, 0b00000001};
//    int len2 = 10;
//    std::size_t len;
//    unsigned char* code = he.concatenateCodes(code1, len1, code2, len2, len);
//    EXPECT_EQ(0b10101100, code[0]);
//    EXPECT_EQ(0b10100110, code[1]);
//    EXPECT_EQ(0b00010001, code[2]);
//    EXPECT_EQ(21, len);
//
//    unsigned char code3[] = {0b10101100, 0b00000101};
//    len1 = 11;
//    unsigned char code4[] = {0b00110100, 0b00000001};
//    len2 = 16;
//    len;
//    code = he.concatenateCodes(code3, len1, code4, len2, len);
//    EXPECT_EQ(0b10101100, code[0]);
//    EXPECT_EQ(0b10100110, code[1]);
//    EXPECT_EQ(0b10000000, code[2]);
//    EXPECT_EQ(0b00000001, code[3]);
//    EXPECT_EQ(27, len);
//}

TEST(HuffmanEncoder, code)
{
    Code code;

    code.eraseByOne();
    EXPECT_EQ(1, code.getValue());
    EXPECT_EQ(1, code.getLen());

    code.eraseByZero();
    EXPECT_EQ(1, code.getValue());
    EXPECT_EQ(2, code.getLen());

    code.eraseByZero();
    EXPECT_EQ(1, code.getValue());
    EXPECT_EQ(3, code.getLen());

    code.eraseByOne();
    EXPECT_EQ(9, code.getValue());
    EXPECT_EQ(4, code.getLen());

    code.eraseByZero();
    EXPECT_EQ(9, code.getValue());
    EXPECT_EQ(5, code.getLen());
}

TEST(HuffmanEncoder, encode)
{
    HuffmanEncoder he;
    std::string s = "mama mila ramu";
    std::size_t textLen = 14, codeLen;
    const unsigned char* text = reinterpret_cast<const unsigned char*>(s.c_str());
    unsigned char* code = he.encode(text, textLen, codeLen);

    
    EXPECT_EQ(228, codeLen);
    EXPECT_EQ(0b10011001, code[0]);
    EXPECT_EQ(0b00110000, code[1]);
    EXPECT_EQ(0b11100100, code[2]);
    EXPECT_EQ(0b10000011, code[3]);
    EXPECT_EQ(0b00000111, code[4]);
}
